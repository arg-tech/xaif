# __init__.py file for the xaif_eval package
from .xaif import AIF  # Make sure the AIF class is imported
